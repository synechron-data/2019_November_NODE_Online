const express = require('express');
const router = express.Router();

const da = require('../data-acccess');

router.get("/", (req, res) => {
    res.render('index', { pageTitle: "Express App" });
});

router.get("/employees", (req, res) => {
    res.render('employees', {
        pageTitle: "Employees View",
        empList: da.getAllEmployees()
    });
});

module.exports = router;