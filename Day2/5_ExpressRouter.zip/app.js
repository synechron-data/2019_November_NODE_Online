const express = require('express');
const logger = require('morgan');

const indexRouter = require('./routes/index');

const app = express();

app.set("view engine", "pug");

app.use(logger('dev'));
app.use('/', indexRouter);

module.exports = app;