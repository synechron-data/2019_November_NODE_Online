const express = require('express');
const router = express.Router();

const emp_ctrl = require('../controllers/employee-controller');

router.get("/", emp_ctrl.index);

module.exports = router;