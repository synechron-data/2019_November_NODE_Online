const express = require('express');
const router = express.Router();

const emp_api_ctrl = require('../controllers/employee-api-controller');

router.get("/employees", emp_api_ctrl.index);

module.exports = router;