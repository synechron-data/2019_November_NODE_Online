const express = require('express');
const logger = require('morgan');

const indexRouter = require('./routes/index');
const employeesRouter = require('./routes/employees');
const apiRouter = require('./routes/api');

const app = express();

app.set("view engine", "pug");

app.use(logger('dev'));
app.use('/', indexRouter);
app.use('/employees', employeesRouter);
app.use('/api', apiRouter);

module.exports = app;