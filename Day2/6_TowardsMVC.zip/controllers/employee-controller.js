const da = require('../data-acccess');

exports.index = (req, res) => {
    res.render('employees/index', {
        pageTitle: "Employees View",
        empList: da.getAllEmployees()
    });
}