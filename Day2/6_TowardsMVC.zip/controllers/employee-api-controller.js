const da = require('../data-acccess');

exports.index = (req, res) => {
    res.json(da.getAllEmployees());
}