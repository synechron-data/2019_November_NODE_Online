const http = require('http');
const fs = require('fs');

var server = http.createServer((req, res) => {
    fs.readFile('./index.html', (err, html) => {
        if (err) throw err;

        res.writeHeader(200, { "content-type": "text/html" });

        res.write(html);
        res.end();
    })
});

server.listen(3000, function () {
    console.log("Server Started.....");
});

const WebSocketServer = require('websocket').server;

const wsServer = new WebSocketServer({
    httpServer: server
});

const StringEmitter = require('./StringEmitter');
const sEmitter = new StringEmitter();
sEmitter.on('data', (s) => {
    if (clients.length > 0) {
        for (const c of clients) {
            if (c) {
                c.sendUTF(s);
            }
        }
    }
});

var count = 0;
var clients = [];

wsServer.on('request', function (req) {
    var connection = req.accept('echo-protocol');

    var id = count++;
    clients[id] = connection;
    console.log(`Connection Accepted [${id}]`);

    connection.on('close', function () {
        delete clients[id];
        console.log(`Connection Closed [${id}]`);
    });
})
