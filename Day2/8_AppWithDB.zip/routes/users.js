var express = require('express');
var router = express.Router();

var user_ctrl = require('../controllers/user-controller');

router.get('/', user_ctrl.index);

router.get('/details/:userid', user_ctrl.details);

router.get('/create', user_ctrl.create_get);

router.post('/create', user_ctrl.create_post);

router.get('/edit/:userid', user_ctrl.edit_get);

router.post('/edit/:userid', user_ctrl.edit_post);

router.get('/delete/:userid', user_ctrl.delete_get);

router.post('/delete/:userid', user_ctrl.delete_post);

module.exports = router;

// M E (A/R) N