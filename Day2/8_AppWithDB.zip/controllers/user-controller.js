const da = require('../data-access');

exports.index = function (req, res, next) {
    da.getAllUsers().then(function (result) {
        res.render('users/index', { title: 'Users View', users: result, message: "" });
    }, (eMsg) => {
        res.render('users/index', { title: 'Users View', users: null, message: eMsg });
    });
};

exports.details = function (req, res, next) {
    var id = req.params.userid;

    da.getUser(id).then(function (result) {
        res.render('users/details', { title: 'User Details View', user: result, message: "" });
    }, (eMsg) => {
        res.render('users/details', { title: 'User Details View', user: null, message: eMsg });
    });
};

exports.create_get = function (req, res, next) {
    res.render('users/create', { title: 'Create New User', user: null, message: "" });
}

exports.create_post = function (req, res, next) {
    var uname = req.body.uname;
    var email = req.body.email;

    var user = { "username": uname, "email": email };

    da.insertUser(user).then((data) => {
        res.redirect('/users');
    }, (eMsg) => {
        res.render('users/create', { title: 'Create New User', user: user, message: eMsg });
    });
}

exports.edit_get = function (req, res, next) {
    var id = req.params.userid;

    da.getUser(id).then(function (result) {
        res.render('users/edit', { title: 'Edit User View', user: result, message: "" });
    }, (eMsg) => {
        res.render('users/edit', { title: 'Edit User View', user: null, message: eMsg });
    });
}

exports.edit_post = function (req, res, next) {
    var uname = req.body.uname;
    var email = req.body.email;

    var user = { "username": uname, "email": email };

    da.updateUser(req.params.userid, user).then((data) => {
        res.redirect('/users');
    }, (eMsg) => {
        res.render('users/edit', { title: 'Edit User View', user: user, message: eMsg });
    });
}

exports.delete_get = function (req, res, next) {
    var id = req.params.userid;

    da.getUser(id).then(function (result) {
        res.render('users/delete', { title: 'Delete User View', user: result, message: "" });
    }, (eMsg) => {
        res.render('users/delete', { title: 'Delete User View', user: null, message: eMsg });
    });
}

exports.delete_post = function (req, res, next) {
    var id = req.params.userid;

    da.deleteUser(id).then(function (result) {
        res.redirect('/users');
    }, (eMsg) => {
        res.render('users/delete', { title: 'Delete User View', user: null, message: eMsg });
    });
}