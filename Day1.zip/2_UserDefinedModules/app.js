// const lib = require('./lib.js');
// const lib = require('./lib');
// console.log(lib);

// lib.log("Hello from App");

// var e1 = new lib.Employee("Manish");
// console.log(e1.Name);
// e1.Name = "Abhijeet";
// console.log(e1.Name);

// const lib1 = require('./lib1');
// console.log(lib1);

// const logger1 = require('./logger1');

const loggerFactory = require('./loggerFactory');

// let dbLogger = loggerFactory.DBLFactory.getLogger();
// let flLogger = loggerFactory.FLFactory.getLogger();

// dbLogger.log("Hello");
// flLogger.log("Hello");

let dbLogger1 = loggerFactory.DBLFactory.getLogger();
let dbLogger2 = loggerFactory.DBLFactory.getLogger();