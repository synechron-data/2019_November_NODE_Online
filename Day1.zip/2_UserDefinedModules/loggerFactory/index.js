// module.exports.DBLFactory = {
//     getLogger: function () {
//         const DBLogger = require('./DBLogger');
//         return new DBLogger();
//     }
// }

// module.exports.FLFactory = {
//     getLogger: function () {
//         const FLLogger = require('./FileLogger');
//         return new FLLogger();
//     }
// }

const DBLFactory = (function DBLFactory() {
    return {
        getLogger: function () {

        }
    };
})();