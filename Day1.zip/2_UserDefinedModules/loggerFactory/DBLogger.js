console.log("DB Logger File Loaded....");

class DBLogger {
    log(message) {
        console.log(`${message}, logged in Database`);
    }
}

module.exports = DBLogger;