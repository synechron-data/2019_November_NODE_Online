var obj = {
    firstname: "Manish",
    lastname: "Sharma",
    log: function (m) {
        console.log(m);
    }
}

module.exports = obj;
// exports = obj;    // Will not work