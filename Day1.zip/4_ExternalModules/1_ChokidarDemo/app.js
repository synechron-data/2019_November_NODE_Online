const chokidar = require('chokidar');

var watcher = chokidar.watch('./Test');

watcher.on('add', (path) => {
    console.log(`File, ${path}, has been created.`)
});

watcher.on('change', (path) => {
    console.log(`File, ${path}, has been changed.`)
});

watcher.on('unlink', (path) => {
    console.log(`File, ${path}, has been deleted.`)
});